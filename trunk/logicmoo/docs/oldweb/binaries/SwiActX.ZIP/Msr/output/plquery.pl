:-dynamic(result/1).

plquery(AtomTerm):-catch( (atom_to_term(AtomTerm,Prolog,_) ,Prolog),Error,post(Error)).

getresult(X):-retract(result(X)).

post(X):-term_to_atom(X,R),assertz(result(R)).


debugcall(X,Y):-!,debugcall(X),debugcall(Y).
debugcall(X;Y):-!,debugcall(X);debugcall(Y).
debugcall(X):-predicate_property(X,built_in),!,X.
debugcall(X):-clause(X,Y),debugcall(Y).

