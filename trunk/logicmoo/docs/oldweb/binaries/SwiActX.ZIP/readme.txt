Instructions for using SWI-Prolog and SWIACTX.

1)  Run w32pl334.exe, which will install SWI-Prolog
    version 3.3.4 onto your machine.

2)  CD to the program directory (probably "C:\Program Files\pl").

3)  Copy the contents of the BIN directory to the SWI-Prolog BIN directory.

4)  Copy the contents of the LIBRARY directory to the SWI-Prolog LIBRARY directory.

5)  From that directory run 'bin\PLCON', and issue the goal 

		make_library_directory(library).

    This causes SWI-Prolog to rebuild the master index of demand-load modules.


Instructions for running the demonstration program.

0)  Be sure you have Office 2000 installed.

1)  Run 'bin\plcon adotest.pl' and issue the goal

		adoTest.

You should see a list of the contents of a query called "QueryWhere" in
the database ADODEMO.MDB.

Contact davidhov@microsoft.com with issues or problems.

For more information on SWI-Prolog, navigate to:

	http://www.swi.psy.uva.nl/projects/SWI-Prolog

