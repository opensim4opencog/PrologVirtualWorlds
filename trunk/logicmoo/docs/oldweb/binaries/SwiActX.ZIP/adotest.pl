%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	Demonstration of using SWIACTX to interface to 
%	Microsoft ADO for database access.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	All result SWIACTX functors are asserted into the
%	Prolog database as:
%
%			adoobj(Name,Functor).
%
%	For example:
%
%			adoobj(connection,activex_object(0))
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%
%	Prefix the demo database name with the Prolog home directory path
%
adoGetFilePath(FileName,Path) :-
		feature(home,HomePath),
		concat_atom([HomePath,'/',FileName],Path).

%
%	Name of test database
%
adoDemoDatabaseName('adodemo.mdb').


%
%
%	Create the ADO connection
%
adoConnect :-
		actx_create_object('ADODB.Connection',IP),
		assertz(adoobj(connection,IP)).

%
%	Compose the ADO connection string for accessing a local 
%		Microsoft Access database
%
adoConStr(StrConn) :-
		adoDemoDatabaseName(StrName),
		adoGetFilePath(StrName,DbPath),
		string_concat('Provider=Microsoft.Jet.OLEDB.4.0;Data Source=',DbPath,StrConn).

%	
%	Open the data source (the adodemo.mdb database)
%
adoOpenSource :-
		adoobj(connection,IPConn),
		adoConStr(StrConn),
		actx_invoke_object(IPConn,'Open',[StrConn],_).

%
%	Create the "recordset" object and open the 'QueryWhere' query
%
adoOpenQuery :-
		actx_create_object('ADODB.Recordset',IPRset),
		assertz(adoobj(recordset,IPRset)),
		adoobj(connection,IPConn),
		actx_invoke_object(IPRset,'Open',['QueryWhere',IPConn],_).

%
%	Prepare the database for access
%
adoPrep :-
		adoConnect,
		write('ADO connection object created'),nl,
		adoOpenSource,
		write('connection to ADODEMO.MDB open'),nl,
		adoOpenQuery,
		write('recordset QueryWhere open'),nl.

%
%	Test for end-of-file on the recordset
%
adoNotEof :-
		adoobj(recordset,IPRset),
		actx_invoke_object(IPRset,['EOF',propget],[],false),
		!.

adoNotEof :-
		nl,write('EOF on recordset'),nl,nl,flush,
		fail.

%
%	Read the next record from the recordset
%
adoReadNext :-
		flush,
        adoNotEof,
		adoobj(recordset,IPRset),
		adoEnumFields,
		actx_invoke_object(IPRset,'MoveNext',[],_),
        adoNotEof,
		adoReadNext.

%
%	Display fields of interest
%
adoEnumFields :-
		adoobj(recordset,IPRset),
		%  Get the Fields collection
		actx_invoke_object(IPRset,['Fields',propget],[],IPFields),
		%  Get the 'Person' Field object and extract its Value property
        actx_invoke_object(IPFields,['Item','propget'],['Person'],IPField1),
		actx_invoke_object(IPField1,['Value','propget'],[],Person),
		write('Next Person is '),
		write(Person),
		%  Get the 'Place' Field object and extract its Value property
        actx_invoke_object(IPFields,['Item','propget'],['Place'],IPField2),
		actx_invoke_object(IPField2,['Value','propget'],[],Place),
		write(', Place is '),
		write(Place),nl.

%
%	Position to the first record and process all of them
%
adoRead :-
		adoobj(recordset,IPRset),
		actx_invoke_object(IPRset,'MoveFirst',[],_),
		adoReadNext.

%
%
%
adoEnd :-
		retractall(adoobj).

%
%
%
adoRun :-
		nl,write('begin ADO demonstration'),nl,
		adoPrep,
		nl,flush,
		not(adoRead),
		adoEnd.

%
%
%
printExcp(StrFunc,StrDesc,TermInError) :-
		nl,
		write('ActiveX Error: '),
		write('in '),write(StrFunc),
		write(', '),write(StrDesc),
		write(', '),write(TermInError),
		nl.

%
%
%
adoTest :-
		adoRun,
		halt.

%
%
%
adoTestExcp :-
		actx_errors_as_exceptions(true),
		catch(adoRun,
				activex_error(StrFunc,StrDesc,TermInError),
				printExcp(StrFunc,StrDesc,TermInError)),
		adoEnd,
		halt.

