/*
	ActiveX interface test module.

		This module uses the foreign predicates defined by SWIACTX.DLL (or
		SWIACTXD.DLL in "debug" mode).   The foreign predicates are
		declared in SWIACTX.PL in the "library" directory and automatically
		loaded due to their inclusion in the "index.pl" file.

		In other word, it just works.  The only caveat is that you must
		change the name of the DLL in SWIACTX.PL to indicate which version
		(release or debug) you want to use.

*/

%
%	This assumes that sources and test files are in $home/src/win32/foreign.
%
owner('Original Owner').

owner(X) :-
		string_to_list(X,"Another Owner").

testPrint(X) :-
		print(X).

