//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Generic.rc
//
#define IDS_SELECTED                    1
#define IDS_SPACE                       2
#define IDS_COMMENT                     3
#define IDS_STRING                      4
#define IDS_KEYWORD                     5
#define IDS_OTHER                       6
#define IDS_RULES                       32
#define IDS_DLL                         33
#define IDS_IDENTIFIERALPHABET          34
#define IDS_ESCAPECHARACTER             35
#define IDS_STRINGCHARACTER             36
#define IDS_CHARACTERCHARACTER          37
#define IDS_FONT                        38
#define IDS_FILETYPES                   39
#define IDS_NESTINGLEVELS               40
#define IDS_SHADING                     41
#define IDS_COMMENTS                    42
#define IDS_LINECOMMENTS                43
#define IDS_UPPKEY                      44
#define IDS_KEYWORDS                    45

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
