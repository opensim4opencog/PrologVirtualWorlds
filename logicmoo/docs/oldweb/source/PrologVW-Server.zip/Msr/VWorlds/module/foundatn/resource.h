// Copyright � 2000 Microsoft Corporation.  All rights reserved.
// In installing/viewing this source code, you agree to the terms of the
// Microsoft Research Source License (MSRSL) included in the root of this source tree
// and available from http://www.vworlds.org/license.asp.

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vwfound.rc
//
#define IDS_FOUNDATIONEXEMPS_DESC       1
#define IDS_VWTRANSACTIONITEMOBJECT_TYPE 2
#define IDS_VWTRANSACTIONITEMOBJECT_DESC 3
#define IDS_VWFOUND_AVATARIGNOREDENIED  3856

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
