#define rmj		1
#define rmm		50
#define rup		280
#define szVerName	""
#define szVerUser	"VWORLDSINT"
