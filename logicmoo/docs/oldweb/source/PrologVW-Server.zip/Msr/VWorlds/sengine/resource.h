// Copyright � 2000 Microsoft Corporation.  All rights reserved.
// In installing/viewing this source code, you agree to the terms of the
// Microsoft Research Source License (MSRSL) included in the root of this source tree
// and available from http://www.vworlds.org/license.asp.

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SEngine.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define ID_INDICATOR_ROWCOL             101
#define IDR_MAINFRAME                   128
#define IDR_SENGINTYPE                  129
#define IDD_CALLSCRIPT                  130
#define IDD_DIALOG1                     131
#define IDD_GOTO                        132
#define IDD_DIALOG2                     133
#define IDD_DIALOG3                     134
#define IDC_EDIT1                       1000
#define IDC_HISTORY                     1001
#define IDC_SOURCE                      1002
#define IDC_ENTER                       1004
#define IDC_COMBO1                      1005
#define IDC_BUTTON1                     1006
#define ID_SCRIPT_LOAD                  32771
#define ID_SCRIPT_INVOKESUB             32772
#define ID_SCRIPT_ENUMERATETYPEINFO     32773
#define ID_WINDOW_COMMANDWINDOW         32775
#define ID_EDIT_GOTOLINE                32778
#define ID_EDIT_GOTO                    32779
#define ID_EDIT_DEBUGOFFBY1             32780
#define ID_WINDOW_NEWOCXWINDOW          32781
#define ID_ACTIVEXCONTROLS_SETCONTROL   32782
#define ID_SCRIPT_TESTMULTITHREADEDVB   32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
